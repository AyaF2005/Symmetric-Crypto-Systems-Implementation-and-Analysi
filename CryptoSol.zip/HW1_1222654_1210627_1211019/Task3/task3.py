from task2_des import des_encrypt_block, des_decrypt_block
from task3_client import query_server

def weak_key_to_des_key(k12):
    k12_bin = format(k12, '012b') + '0' * 44
    key64 = ''
    for i in range(8):
        block = k12_bin[i * 7:(i + 1) * 7]
        key64 += block + '0'
    return key64.zfill(64)  
def verify_triple_des(plain_bin, cipher_bin, k1, k2):
    k1_key = weak_key_to_des_key(k1)
    k2_key = weak_key_to_des_key(k2)
    temp1 = des_encrypt_block(plain_bin, k1_key)
    temp2 = des_decrypt_block(temp1, k2_key)
    temp3 = des_encrypt_block(temp2, k1_key)
    return temp3 == cipher_bin
def mitm_attack(plain_hex, cipher_hex):
    print("Starting attack.")
    plain_bin = bin(int(plain_hex, 16))[2:].zfill(64)
    cipher_bin = bin(int(cipher_hex, 16))[2:].zfill(64)
    enc_map = {}
    print("Generating Enc map for all 12-bit K1 values.")
    for k1 in range(4096):
        try:
            k1_key = weak_key_to_des_key(k1)
            mid = des_encrypt_block(plain_bin, k1_key)
            enc_map[mid] = k1
        except Exception as e:
            print(f"Error with K1={k1}: {e}")
            continue
    print("Searching for a matching K2.")
    for k2 in range(4096):
        try:
            k2_key = weak_key_to_des_key(k2)
            mid = des_decrypt_block(cipher_bin, k2_key)

            if mid in enc_map:
                k1 = enc_map[mid]
                print(f"[+] Potential match: K1={k1}, K2={k2}")
                if verify_triple_des(plain_bin, cipher_bin, k1, k2):
                    return k1, k2
        except Exception as e:
            print(f"Error with K2={k2}: {e}")
            continue
    print("No valid keys found.")
    return None, None
def main():
    plaintext = "0123456789ABCDEF"
    ciphertext = query_server("1211019", plaintext)
    print(f"Plaintext : {plaintext}")
    print(f"Ciphertext: {ciphertext}")
    k1, k2 = mitm_attack(plaintext, ciphertext)
    if k1 is not None:
        print("\n[SUCCESS] Keys successfully recovered:")
        print(f"K1 (12-bit)      : {k1} (0x{k1:03X})")
        print(f"K2 (12-bit)      : {k2} (0x{k2:03X})")
        print("\nFull 64-bit DES keys:")
        print(f"K1 (64-bit key)  : {weak_key_to_des_key(k1)}")
        print(f"K2 (64-bit key)  : {weak_key_to_des_key(k2)}")
    else:
        print("Attack failed. Keys not found.")

if __name__ == "__main__":
    main()