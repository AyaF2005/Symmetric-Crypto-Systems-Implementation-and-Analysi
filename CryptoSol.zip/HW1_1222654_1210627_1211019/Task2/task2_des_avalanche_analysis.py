import random
from task2_des import des_encrypt_block

def flip_bit(bits, index):
    flipped = list(bits)
    flipped[index] = '1' if bits[index] == '0' else '0'
    return ''.join(flipped)

def count_diff_bits(a, b):
    return sum(x != y for x, y in zip(a, b))

def random_64bit():
    return ''.join(random.choice('01') for _ in range(64))

def random_56bit():
    return ''.join(random.choice('01') for _ in range(56)).ljust(64, '0')

def main():
    print("| Experiment | Type     | Diff bits |")
    print("|------------|----------|-----------|")
    for i in range(1, 11):
        P = random_64bit()
        K = random_56bit()

        C1 = des_encrypt_block(P, K)

        # flip plaintext
        idx_p = random.randint(0, 63)
        P_flipped = flip_bit(P, idx_p)
        C2_p = des_encrypt_block(P_flipped, K)
        diff_p = count_diff_bits(C1, C2_p)

        # flip key
        idx_k = random.randint(0, 55)
        K_flipped = flip_bit(K, idx_k)
        C2_k = des_encrypt_block(P, K_flipped)
        diff_k = count_diff_bits(C1, C2_k)

        print(f"| {i:<10} | Plaintext | {diff_p:<9} |")
        print(f"| {i:<10} | Key       | {diff_k:<9} |")

if __name__ == "__main__":
    main()
