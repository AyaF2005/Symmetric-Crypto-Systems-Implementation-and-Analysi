from task2_des import des_encrypt_block, des_decrypt_block

def hex_to_bin(hex_str):
    return bin(int(hex_str, 16))[2:].zfill(64)

def bin_to_hex(bin_str):
    return hex(int(bin_str, 2))[2:].zfill(16)

def main():
    choice = input("Choose operation (E for encryption, D for decryption): ").upper()
    text_hex = input("Enter text (64-bit hex): ").strip()
    key_hex = input("Enter key (56-bit hex without parity): ").strip()

    key_bin = hex_to_bin(key_hex).ljust(64, '0')  # Fill the remaining 8 bits with zero
    text_bin = hex_to_bin(text_hex)

    if choice == 'E':
        result_bin = des_encrypt_block(text_bin, key_bin)
    elif choice == 'D':
        result_bin = des_decrypt_block(text_bin, key_bin)
    else:
        print("Invalid choice")
        return

    print(f"Result (hex): {bin_to_hex(result_bin)}")

if __name__ == "__main__":
    main()
